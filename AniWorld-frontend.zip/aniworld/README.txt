AniWorld — beginner frontend starter

HOW TO RUN
1. Extract the ZIP file.
2. Open the aniworld folder.
3. Double-click index.html to open it in Chrome, Edge, or Firefox.
4. Search, filter genres, open details, add items to your watchlist, and try the Admin panel.

WHAT IS INCLUDED
- Responsive dark anime catalogue UI
- Search and genre filters
- Anime details and generated episode list
- Browser-local watchlist
- Demo admin panel to add/delete anime
- Saves catalogue and watchlist in this browser with localStorage

IMPORTANT LIMITATIONS
- This is a frontend demo. It has no real user accounts, secure admin login, server database, or video hosting.
- Admin changes are stored only in the current browser. Anyone using that browser can access the demo admin panel.
- Episode rows are placeholders, not playable videos. Only add video links/content that you own or are authorized to distribute.
- The sample titles/descriptions are fictional. Replace poster URLs with images you have permission to use.

NEXT STEP FOR A REAL PUBLIC WEBSITE
Deploy the static files using Cloudflare Pages (free tier), then add a backend such as Supabase for secure admin authentication, shared anime data, and watchlists.
